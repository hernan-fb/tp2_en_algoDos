/*
 * Pruebita.cpp
 *
 *  Created on: May 6, 2019
 *      Author: root
 */

#include "Pruebita.h"

namespace std {

Pruebita::Pruebita() {
	// TODO Auto-generated constructor stub

}

Pruebita::~Pruebita() {
	// TODO Auto-generated destructor stub
}

int Pruebita::haceAlgo() {
	return 42;
}

} /* namespace std */
