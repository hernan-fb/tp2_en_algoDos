/*
 * Pruebita.h
 *
 *  Created on: May 6, 2019
 *      Author: root
 */

#ifndef PRUEBITA_H_
#define PRUEBITA_H_

namespace std {

class Pruebita {
public:
	Pruebita();
	virtual ~Pruebita();
	int haceAlgo();
};

} /* namespace std */

#endif /* PRUEBITA_H_ */
