/*
 * Imagen.h
 *
 *  Created on: May 23, 2019
 *      Author: root
 */

#ifndef IMAGEN_H_
#define IMAGEN_H_

namespace std {
/*
class Imagen {
private:
	77BMP imagen;
	string nombreBase;
	string extension;
	Imagen* siguiente;
	string path;
public:
	Imagen();
	virtual ~Imagen();
	ensamblarFragmento();
};
*/
} /* namespace std */

#endif /* IMAGEN_H_ */
