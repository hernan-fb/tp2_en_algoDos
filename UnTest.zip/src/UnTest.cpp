//============================================================================
// Name        : UnTest.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <sstream>
#include "Pruebita.h"
#include "EasyBMP.h"
#include "EasyBMP_DataStructures.h"
#include "Tablero.h"
#include "Ficha.h"

using namespace std;
#define X 20
#define Y 20
#define Z 20
#define A 5

bool insertarImagen(BMP *base, BMP *fragment, int x, int y, int width, int height) { // pre: i< base->TellWidth()
	for (int i = x; i< ( x+width ); i++) {
		for (int j = y; j< ( y+height ); j++ ) {
				base->SetPixel( i, j, fragment->GetPixel(i-x,j-y) );
		}
	}
	return true;
}

template <typename T>
string convertirEnStr( const T & t ) {
   ostringstream os;
   os << t;
   return os.str();
}

int main( ) // int argc, char* argv[] )
{
	int dimension_tablero[3] = {X,Y,Z};
	int unaUbicacionEnTablero[3];
	int cantidadDeJugadores = A;

	BMP **outputPiso = new BMP*[Z]; // de tamanio Z porque las imagenes son tomadas a través de los ejes X e Y
	// BMP **outputFrontal[Y]; // de tamanio Y porque las imágenes son tomadas a través de los ejes X y Z
	// BMP **outputLateral[X]; // de tamanio X porque las imágenes son tomadas a través de los ejes Y y Z
	BMP **circle = new BMP*[A]; // de tamanio A porque es la cantidad de jugadores..

	Ficha *fichita;
	BMP 	*outputTest = new BMP();
	Tablero *elTableroDeUnTest = new Tablero(dimension_tablero);

	// una version pseudo-aleatoria del juego jajaj
	for ( int i = 1; i <= X; i++) {
		for ( int j = 1; j <= Y; j++) {
			for (int jj = 1; jj <= Z; jj++) { // i*i + 2*j + jj*j*i
				if ( -(i-X/2)*(i-X/2)/X-(j-Y/2)*(j-Y/2)/Y +Z > jj ) {
				fichita = new Ficha(( i*i+j+jj*j) % A + 1); //el +1 es para que los jugadores estén desde 1 hasta A;
				unaUbicacionEnTablero[0] = i;
				unaUbicacionEnTablero[1] = j; // como seria en una linea? 	unaUbicacionEnTablero = {i,j,jj}; ¿? no funcionó!
				unaUbicacionEnTablero[2] = jj;
				// fichita->color = circle.GetColor() //habría que usar esta funcion si se quiere llenar las fichas en tiempo de ejecución.
				elTableroDeUnTest->guardarFicha(fichita, unaUbicacionEnTablero);
				}
			}
		}
	}

	/*---- Version para leer las fichas de los jugadores ----*/
	string str;
	const char * c;
	for (int i = 0; i< A; i++) {
		circle[i] = new BMP();
		str = string ("/home/hernan/workspace/UnTest/Imagenes/Load/")
			  + string ("circle")
			  + convertirEnStr(i+1)
			  + string (".bmp");
		c = str.c_str();
		circle[i]->ReadFromFile(c);//argv[1] );
	}

	/* ==== 				========					====*/

	//cout << "Tablerito: alto: " << outputPiso->TellHeight() << ", ancho: " << outputPiso->TellWidth() << ". ";
	cout << "Circulo: alto: " << circle[0]->TellHeight() << ", ancho: " << circle[0]->TellWidth() << ". ";

	/*----Version para obtener imágenes de las plantas---- */

		//for para leer las fichas en todas las posiciones
		int numeroDeJugador;

		cout << "abc";
		int widthInsertarImagen = circle[0]->TellWidth();
		int heigthInsertarImagen = circle[0]->TellHeight();
		BMP *output;// = new BMP();
		for (int jj = 0; jj < Z; jj++) {
			outputPiso[jj] = new BMP(); // tiene las dimensiones de la planta
			outputPiso[jj]->SetSize(X*widthInsertarImagen,Y*heigthInsertarImagen); //
			for (int i=0; i < X; i++) {
				for (int j=0; j< Y; j++) {
					unaUbicacionEnTablero[0] = i+1;
					unaUbicacionEnTablero[1] = j+1; // como seria en una linea?  unaUbicacionEnTablero = {i,j,jj}; ¿? no funcionó!
					unaUbicacionEnTablero[2] = jj+1;//jj+1;
					if (elTableroDeUnTest->posicionVacia(unaUbicacionEnTablero)) {
					numeroDeJugador = elTableroDeUnTest->obtenerFicha(unaUbicacionEnTablero)->darNumero();
					cout << numeroDeJugador<<" i:"<<i<<" j:"<<j<<endl;
					//Estas son dos alternativas para hacer el copiado. Ambas tiran el mismo error en ejecucion...
					//RangedPixelToPixelCopy( *circleTest, 0, widthInsertarImagen-1, 0, heigthInsertarImagen-1, *output, widthInsertarImagen * i, heigthInsertarImagen * j );
					insertarImagen(outputPiso[jj],circle[numeroDeJugador-1],i*widthInsertarImagen,j*heigthInsertarImagen, widthInsertarImagen,heigthInsertarImagen);
				}	}
			}
		}
	/* ==== 				========					====*/

	/*---- Version para guardar las imágenes de Tablero ----*/
	//string str;
	//const char * c;
	for (int jj = 0; jj < Z; jj++) {
		str = string("/home/hernan/workspace/UnTest/Imagenes/Generated/")
			  + string("TableritoBaseNivel")
			  + convertirEnStr(jj) //jj
			  + string(".bmp") ;
		c = str.c_str();
		outputPiso[jj]->WriteToFile(c); //
	}
	/* ===== 				========					====*/

	cout << "archivo ejecutado!";

	return 0;
}
