/*
 * Imagen.cpp
 *
 *  Created on: May 23, 2019
 *      Author: root
 */

#include "Imagen.h"

namespace std {
/*
Imagen::Imagen() {
	// TODO Auto-generated constructor stub

}

Imagen::~Imagen() {
	// TODO Auto-generated destructor stub
}
*/
} /* namespace std */
